'use strict';

// dependicies
// let async = require('async');
let AWS = require('aws-sdk');
// let util = require('util');
// let image = require('./img/baked-goods.JPG')
// let uuid = require('uuid').v4

let s3 = new AWS.S3();

// setup our lambda handler
exports.handler = function (event, context, callback) {
  console.log('Eveeryting Under Event',JSON.stringify(event)); 
  // START HERE!! 
  // console.log('Util',util.inspect(event, { depth }))
  console.log('content', JSON.stringify(context))
  // console.log('callback', JSON.stringify(callback))
  // run all functions that are dependent on the return from the function above
  // async.waterfall();

  // let a user upload an image of any size
  let params = { Bucket: "lambbucket11", Key: "baked-goods.JPG", Body: "baked-goods.JPG"};
  // let params = { Bucket: "lambbucket11", Key: uuid(), Body: image};
  s3.upload(params, function (err, data) {
    console.log('s3.upload', 'err', err, 'data', data)
  });
  // contentType: "JPG"

  // get images.json
  // let params2 = { Bucket: "lambbucket11", Key: "baked-goods.JPG" }
  let params2 = { Bucket: "lambbucket11", Key: "baked-goods.JPG" }

  s3.getObject(params2, function(err, data) {
    if (err) console.log(err, err.stack); // an error occurred
    else console.log(data);           // successful response
  }); // get images.json

  // let a user update:Create, Delete, rename? a dictionary, an array of images, of all images
  // when uploaded -> dwnlod images.json(dictionary of images) -> array of objs(images), create array if none
  // return meta data obj = image: name, Size, type, etc
  // append new image to dictionary
  // upload image.json to S3
}

